package com.example.thequizzler;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.Toast;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    private Button mTrueButton; //Establishing variables (buttons and text view)
    private Button mFalseButton;
    private Button mNextButton;
    private Button mPreviousButton;
    private TextView mQuestionTextView;

    private Question[] mQuestionBank =new Question[] { //Establishing questions array
        new Question(R.string.question_madison, true),
        new Question(R.string.question_milwaukee, false),
        new Question(R.string.question_chicago, true),
        new Question(R.string.question_bird, true),
        new Question(R.string.question_tree, false),
        new Question(R.string.question_midwest, false),
    };


    private int mCurrentIndex = 0;

    //Overrides the parent method
    @Override
    protected void onCreate(Bundle savedInstanceState) {   //onCreate is needed for activities to run
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mQuestionTextView = (TextView) findViewById(R.id.question_text_view);

        mTrueButton = (Button) findViewById(R.id.true_button); //code for true button
        mTrueButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    checkAnswer(true);
                }

        });
        mFalseButton =(Button) findViewById(R.id.false_button); //code for false button
        mFalseButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    checkAnswer(false);
                }
        });


        mNextButton =(Button) findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener() {
                                           @Override
                                           public void onClick(View v) {
                                               if (mCurrentIndex == mQuestionBank.length - 1) {
                                                   mCurrentIndex = 0;
                                               } else {
                                                   mCurrentIndex++;
                                               }
                                               updateQuestion();
                                           }
                                       });
                mPreviousButton = (Button) findViewById(R.id.previous_button);

                mPreviousButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mCurrentIndex == 0) {
                            mCurrentIndex = mQuestionBank.length - 1;
                        } else {
                            mCurrentIndex--;
                        }
                        updateQuestion();
                    }
                });

                updateQuestion();
            }


    private void updateQuestion() {
        int question = mQuestionBank[mCurrentIndex].getTextResId();
        mQuestionTextView.setText(question);
    }
    private void checkAnswer(boolean userPressedTrue) { //accepts a boolean to ID if the user pressed true or false.
        boolean answerIsTrue = mQuestionBank[mCurrentIndex].isAnswerTrue(); //checks if the answer is saved as being true or false.

        int messageResId = 0;

        if (userPressedTrue == answerIsTrue) {
            messageResId = R.string.correct_toast; //determines if user is correct or not and stores the correct or incorrect toast.
        } else {
            messageResId = R.string.incorrect_toast;
        }

        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show(); //instructs the toast to display on the view layer.
    }

    }